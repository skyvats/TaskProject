import React, {useState} from 'react';
import logo from './logo.svg';
import './App.css';
import {ButtonCom} from "./commoncomponent/ButtonComp";
import {TaskSelectionComp} from "./commoncomponent/TaskSelectionComp";
import {FirstTask} from "./task1/FirstTaskComponent";
import {SecondTask} from "./task2/SecondTaskComponent";

function App() {

    const [selectedTask, setSelectedTask] = useState<any>(null);

    return (
        <div className="App">
            {
                selectedTask === null ?
                    <TaskSelectionComp setSelectedTask={setSelectedTask}/> :
                    <>
                        {selectedTask === "task-1" ?
                            <FirstTask/>
                            :
                            <SecondTask/>}
                    </>
            }
        </div>
    );
}

export default App;
