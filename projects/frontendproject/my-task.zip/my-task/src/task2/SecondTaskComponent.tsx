import React, {useEffect, useState} from "react";
import {ButtonCom} from "../commoncomponent/ButtonComp";
import './secondtaskstyle.css'
import axios from "axios";

export const SecondTask=()=>{

    const [inputValue, setInputValue] = useState<any>("");
    const [tableData, setTableData] = useState<any>([])

    useEffect(()=>{
        //getAllWebSites();

        axios.get("http://localhost:8999/getAllWebsites", {params: {"websiteDetails": JSON.stringify({})}}).then(function (response) {
            console.log("getAllWebsites response = ", response);
            const data = response.data;
            setTableData(data);
        });
       /* const intervalId = setInterval((check:any) => {
            getAllWebSites();
        }, 120000);*/
    },[])

    const getAllWebSites=()=>{
        axios.get("http://localhost:8999/getAllWebsites", {params: {"websiteDetails": JSON.stringify({})}}).then(function (response) {
            console.log("getAllWebsites response = ", response);
            const data = response.data;
            setTableData(data);
        });
    }

    const isValidUrl=(userInput:any)=>{
        var regexQuery = "(http(s|)\\:\\/\\/|)((([a-zA-Z0-9-_]{1,}\\.){1,})([a-zA-Z]{1}[a-zA-Z0-9-]{1,}))(:[0-9]{1,}|)(\\/[a-zA-Z0-9_~#?\\+\\&\\.\\/-=%-]{1,}|)";
        var url:any = new RegExp(regexQuery,"i");
        return url.test(userInput);
    }

    const addWebsiteToDB=()=>{
        console.log("Invoked addWebsiteToDB");

        var websiteDetails:any = {};
        var validURL:any = isValidUrl(inputValue);
        console.log("validURL ====> ", validURL);
        if(!validURL){
            alert("Not a valid URL");
            return;
        }
        websiteDetails["websiteName"] = inputValue;

        axios.get("http://localhost:8999/addWebsite", {params: {"websiteDetails": JSON.stringify(websiteDetails)}}).then(function (response) {
            console.log("Add User response = ", response);
            const data = response.data;

            setInputValue("");
            getAllWebSites();
        });
    }

    const onInputChange=(e:any)=>{
        setInputValue(e.target.value);
    }

    return(
        <>
            <div className="grid">
                <div className="col-12" style={{padding:"1%", textAlign:"center"}}>
                    <input style={{width:"20%", height:"30px"}} value={inputValue} onChange={(e:any)=>onInputChange(e)} placeholder={"Enter Website here to be monitored"}/>
                </div>
                <div className="col-12 pt-3" style={{padding:"1%"}}>
                    <ButtonCom id={"task-2-submit"} label={"ADD"} color="rgb(234 234 234)" onClick={addWebsiteToDB}/>
                </div>
                <div className="col-12" style={{display: "flex", justifyContent: "center", alignItems: "center", margin: 0}}>
                    <table>
                        <thead>
                            <tr >
                                <th >Website</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                tableData.map((data:any)=>{
                                    return(
                                        <tr>
                                            <td><a href={data.website} style={{color:"skyblue"}}>{data.website}</a></td>
                                            <td>
                                                {data.status === "SUCCESS" ?
                                                    <ButtonCom id={Math.round(Math.random()*10000)} label={data.status} color="rgb(180 233 182)" /> :
                                                    <ButtonCom id={Math.round(Math.random()*10000)} label={data.status} color="rgb(245 204 153)" />
                                                }
                                            </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>

                    </table>
                </div>
            </div>
        </>
    )
}