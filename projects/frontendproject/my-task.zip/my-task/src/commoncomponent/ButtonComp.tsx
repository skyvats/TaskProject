import React from "react";

export const ButtonCom=(props:any)=>{

    return(
        <button id={props.id} style={{background:props.color, height:"35px", width:"120px", borderRadius:"8px"}} onClick={(e:any)=>props.onClick(e)}>{props.label}</button>
    )
}