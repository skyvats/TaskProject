import React, {useState} from "react";
import {ButtonCom} from "../commoncomponent/ButtonComp";
import axios from "axios";

export const FirstScreen=()=>{

    const [tableName, setTableName] = useState<any>("");
    const [uniqueColumn, setUniqueColumn] = useState<any>("");
    const [columnName, setColumnName] = useState<any>("");

    const[showInputScreen, setShowInputScreen] = useState<any>(true);

    const[tableDataList, setTableDataList] = useState<any>([]);
    const[tableDataObject, setTableDataObject] = useState<any>([]);

    const getTableDetails=()=>{
        console.log("Invoked getTableDetails");
        console.log("tableName => ", tableName);
        console.log("uniqueColumn => ", uniqueColumn);
        console.log("columnName => ", columnName);

        if(tableName === "" || uniqueColumn === "" || columnName === ""){
            alert("Enter All Values");
            return;
        }

        const tableDetails:any = {};
        tableDetails["tableName"] = tableName;
        tableDetails["uniqueColumn"] = uniqueColumn;
        tableDetails["columnName"] = columnName;

        axios.get("http://localhost:8999/getSpecificColumn", {params: {"tableDetails": JSON.stringify(tableDetails)}}).then(function (response) {
            console.log("getSpecificColumn response = ", response);
            const data = response.data;

            if(data === undefined || data === null || data === "" || data.length <= 0){
                alert("Table Details Not Valid");
            }
            else{
                createTableData(data);
                setShowInputScreen(false);
            }

        }).catch((err:any)=>{
            alert("Table Details Not Valid");

            console.log("Table Details Not Valid: ",err);
        });
    }

    const createTableData=(dataList:any)=>{
        console.log("Involed createTableData => ", dataList);

        var tempTableDataList:any = [];
        dataList.map((data:any)=>{
            tempTableDataList.push({tableName:tableName, columnName:columnName, value:data});
        })
        //setTableDataList(dataList);
        setTableDataObject(tempTableDataList);
    }

    const onInputTextChange=(e:any)=>{
        var tempObject:any = [];
        tableDataObject.map((data:any)=>{
            if(data.value === e.target.id.split("_%$$%_")[0]){
                data.newValue = e.target.value;
            }
            tempObject.push(data);
        })
        setTableDataObject(tempObject);
    }

    const getUpdatedTableDetails=()=>{
        console.log("Invoked getUpdatedTableDetails => ", tableDataObject);
        tableDataObject.map((data:any)=>{
            console.log("Data$$$$$ => ", data);
            if(data.newValue !== undefined && data.newValue !== null){
                const tableDetails:any = {};

                tableDetails["tableName"] = tableName;
                tableDetails["columnName"] = columnName;
                tableDetails["oldDistinctValue"] = data.value;
                tableDetails["updatedValue"] = data.newValue;

                axios.get("http://localhost:8999/updateRows", {params: {"tableDetails": JSON.stringify(tableDetails)}}).then(function (response) {
                    console.log("getSpecificColumn response = ", response);
                    const data = response.data;
                    if(data === "SUCCESS"){
                        console.log("Table Updated Successfully");
                    }

                }).catch((err:any)=>{
                    alert("Table Details Not Valid");

                    console.log("Table Details Not Valid: ",err);
                });
            }
        })
    }

    return(
        <>
            {
                showInputScreen ?
                    <div className="grid">
                        <div className="col-12" style={{padding:"1%", textAlign:"center"}}>
                            <input style={{width:"17%", height:"30px"}} value={tableName} onChange={(e:any)=>setTableName(e.target.value)} placeholder={"Table Name"}/>
                        </div>
                        <div className="col-12" style={{padding:"1%", textAlign:"center"}}>
                            <input style={{width:"17%", height:"30px"}} value={uniqueColumn} onChange={(e:any)=>setUniqueColumn(e.target.value)} placeholder={"Unique Column"}/>
                        </div>
                        <div className="col-12" style={{padding:"1%", textAlign:"center"}}>
                            <input style={{width:"17%", height:"30px"}} value={columnName} onChange={(e:any)=>setColumnName(e.target.value)} placeholder={"Column Name"}/>
                        </div>
                        <div className="col-12 pt-3" style={{padding:"1%"}}>
                            <ButtonCom id={"task-2-submit"} label={"Manual Update"} color="rgb(234 234 234)" onClick={getTableDetails}/>
                        </div>
                    </div>
                    :
                    <div className={"grid"}>
                        <div className="grid" style={{display: "flex", justifyContent: "center", alignItems: "center", marginTop: 50}}>
                            <table>
                                <thead>
                                <tr >
                                    <th>Table Name</th>
                                    <th>Column Name</th>
                                    <th style={{background:"green"}}>Distinct Value</th>
                                    <th style={{background:"orange"}}>User Input</th>
                                </tr>
                                </thead>
                                <tbody>
                                {
                                    tableDataObject.map((data:any)=>{
                                        return(
                                            <tr key={data.value}>
                                                <td>{data.tableName}</td>
                                                <td>{data.columnName}</td>
                                                <td>{data.value}</td>
                                                <td><input key={data.value+"_%$$%_INPUT"} id={data.value+"_%$$%_INPUT"} onChange={(e:any)=>{onInputTextChange(e)}}/></td>
                                            </tr>
                                        )
                                    })
                                }
                                </tbody>

                            </table>
                        </div>
                        <div>
                            <div className="col-12 pt-3" style={{padding:"1%"}}>
                                <ButtonCom id={"task-2-submit"} label={"Update"} color="rgb(234 234 234)" onClick={getUpdatedTableDetails}/>
                            </div>
                        </div>
                    </div>
            }

        </>


    )
}