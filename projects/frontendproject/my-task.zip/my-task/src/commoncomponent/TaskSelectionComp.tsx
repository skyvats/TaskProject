import React from "react";
import {ButtonCom} from "./ButtonComp";

export const TaskSelectionComp=(props:any)=>{

    const taskSelection=(e:any)=>{
        console.log("Invoked taskSelection => ",e);
        props.setSelectedTask(e.target.id);
    }

    return(
        <div className="grid">
            <div className="col-6" style={{padding:"1%", textAlign:"center"}}>
                <ButtonCom id={"task-1"} label={"Task-1"} color="lightgreen" onClick={taskSelection}/>
            </div>
            <div className="col-6 p-4" style={{padding:"1%", textAlign:"center"}}>
                <ButtonCom id={"task-2"} label={"Task-2"} color="lightgreen" onClick={taskSelection}/>
            </div>
        </div>
    )
}