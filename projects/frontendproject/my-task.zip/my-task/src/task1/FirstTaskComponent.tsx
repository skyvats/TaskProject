import React from "react";
import {FirstScreen} from "./FirstScreen";

export const FirstTask=()=>{
    return(
        <div>
            <FirstScreen/>
        </div>
    )
}